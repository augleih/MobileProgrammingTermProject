package org.androidtown.dailymanager;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class HomeActivity extends AppCompatActivity {

    private ImageButton historyBtn,writeBtn,homeBtn,accountBtn;
    private Intent i;

    private HomeFragment homeFragment;
    private WriteFragment writeFragment;

    public static UserDataStore storage=new UserDataStore();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        init();
        setListener();
    }

    public void init(){
        historyBtn=findViewById(R.id.historyBtn);
        writeBtn=findViewById(R.id.writeBtn);
        homeBtn=findViewById(R.id.homeBtn);
        accountBtn=findViewById(R.id.accountBtn);

        homeBtn.setImageResource(R.drawable.on_home_icon);

        writeFragment=new WriteFragment();
        homeFragment=new HomeFragment();

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment,homeFragment).commit();
    }
    public void setListener(){

        historyBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                setHistoryIntent();
                startActivity(i);
                overridePendingTransition(0,0);
            }
        });

        writeBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                writeBtn.setImageResource(R.drawable.on_writing_icon);
                homeBtn.setImageResource(R.drawable.home_icon);
                getSupportFragmentManager().beginTransaction().setCustomAnimations(R.anim.layout_leftin,R.anim.layout_leftout).replace(R.id.fragment,writeFragment).commit();
            }
        });

        homeBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                homeBtn.setImageResource(R.drawable.on_home_icon);
                writeBtn.setImageResource(R.drawable.writing_icon);
                returnHome();
            }
        });

        accountBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                setAccountIntent();
                startActivity(i);
                overridePendingTransition(0,0);
            }
        });
    }
    public void setAccountIntent(){i=new Intent(this,AccountActivity.class);}
    public void setHistoryIntent(){ i=new Intent(this,HistoryActivity.class);}

    public void returnHome(){
        writeBtn.setImageResource(R.drawable.writing_icon);
        homeBtn.setImageResource(R.drawable.on_home_icon);
        getSupportFragmentManager().beginTransaction().setCustomAnimations(R.anim.layout_rightin,R.anim.layout_rightout).replace(R.id.fragment,homeFragment).commit();
    }

    public void setData(String date,String txt){
        storage.addText(date,txt);
    }
    public String getData(){
        return storage.getString();
    }
}

