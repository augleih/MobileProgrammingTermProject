package org.androidtown.dailymanager;

import java.util.HashMap;

public class UserDataStore {

    private HashMap<String, String> txtSet=new HashMap<>();

    public void addText(String date,String txt){
        txtSet.put(date,txt);
    }

    public String getString(){
        String tmp="";
        for(String key:txtSet.keySet()){
            tmp+=key+" : "+txtSet.get(key)+",";
        }
        return tmp;
    }
    public void  splitText(){

    }
}


