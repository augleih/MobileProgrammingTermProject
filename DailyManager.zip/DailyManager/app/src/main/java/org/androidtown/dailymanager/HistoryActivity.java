package org.androidtown.dailymanager;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;

public class HistoryActivity extends AppCompatActivity {

    GridLayout gridLayout;
    Button cancelBtn,submitBtn;
    Intent i;
    ImageView imgView1,imgView2,imgView3,imgView4,imgView5;


    private int imgNum=1;
    private String folderName="background";
    private String imgName;
    private String storagePath;
    private StorageReference mStorageRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history);

        init();
        setListener();

        StorageReference mStorageRef= FirebaseStorage.getInstance().getReference();

        for(int index=0;index<6;index++) {
            String imgName = String.format("img%d.jpg", index);
            String storagePath = folderName + "/" + imgName;
            StorageReference imageRef = mStorageRef.child(storagePath);

            try {
                final File imageFile = File.createTempFile("images", "jpg");
                imageRef.getFile(imageFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                        Bitmap bitmapImage = BitmapFactory.decodeFile(imageFile.getPath());
                        switch(imgNum) {
                            case 1:imgView1.setImageBitmap(bitmapImage);break;
                            case 2:imgView2.setImageBitmap(bitmapImage);break;
                            case 3:imgView3.setImageBitmap(bitmapImage);break;
                            case 4:imgView4.setImageBitmap(bitmapImage);break;
                            case 5:imgView5.setImageBitmap(bitmapImage);break;
                            default:break;
                        }
                        imgNum++;
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        e.printStackTrace();
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void init(){
        cancelBtn=findViewById(R.id.cancelBtn);
        submitBtn=findViewById(R.id.submitBtn);
        gridLayout=findViewById(R.id.gridLayout);
        imgView1=findViewById(R.id.img1);
        imgView2=findViewById(R.id.img2);
        imgView3=findViewById(R.id.img3);
        imgView4=findViewById(R.id.img4);
        imgView5=findViewById(R.id.img5);
    }

    public void setListener(){

        cancelBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                finish();
            }
        });

        submitBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

            }
        });
    }
}