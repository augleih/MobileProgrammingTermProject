package org.androidtown.dailymanager;

import android.app.DatePickerDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class WriteFragment extends Fragment implements View.OnClickListener {

    private TextView dateTxtView;
    private ImageButton dateBtn;
    private Button doneBtn;
    private ImageButton addImgBtn;
    private ImageView imgView;
    private EditText edt;

    private SimpleDateFormat fmDateAndTime, simpleDateFormat;
    private Calendar date= Calendar.getInstance();

    private StorageReference mStorageRef;

    private int imgNum=1;
    private String folderName="background";
    private String imgName;
    private String storagePath;
//
    DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener(){
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth){
            date.set(Calendar.YEAR, year);
            date.set(Calendar.MONTH, monthOfYear);
            date.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            updateLabel();
        }
    };

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_write, container, false);

        dateTxtView = rootView.findViewById(R.id.dateTxtView);
        dateBtn = rootView.findViewById(R.id.dateBtn);
        doneBtn=rootView.findViewById(R.id.saveOnWriteBtn);
        addImgBtn=rootView.findViewById(R.id.addImgBtn);
        imgView=rootView.findViewById(R.id.imgBackground);
        edt=rootView.findViewById(R.id.editText);

        init();
        dateInit();
        setListener();
        dateBtn.setOnClickListener(this);

        mStorageRef=FirebaseStorage.getInstance().getReference();

        addImgBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imgName=String.format("img%d.jpg",imgNum++);
                storagePath=folderName+"/"+imgName;

                if(imgNum==6)
                    imgNum=1;
                StorageReference imageRef=mStorageRef.child(storagePath);

                try{
                    final File imageFile=File.createTempFile("images","jpg");
                    imageRef.getFile(imageFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                            Bitmap bitmapImage= BitmapFactory.decodeFile(imageFile.getPath());
                            imgView.setImageBitmap(bitmapImage);
                        }
                    }).addOnFailureListener(new OnFailureListener(){
                        @Override
                        public void onFailure(@NonNull Exception e){
                            e.printStackTrace();
                        }
                    });
                }catch(IOException e){
                    e.printStackTrace();
                }
            }
        });
        return rootView;

    }

    public void init(){
        fmDateAndTime = new SimpleDateFormat("yyyy.MM.dd", Locale.KOREA); // 변경 시 받을 년, 월, 일 정보
        simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd", Locale.KOREA); // 시간 년,월,일 형식으로 한국 기준 시간 받아오기
    }

    public void dateInit(){ // 날짜 당일 날로 초기화 메서드
        Date currentTime = new Date(); // Date 클래스 변수 선언
        String today = simpleDateFormat.format(currentTime); // today 스트링 변수에 currentTime 변수 불러와 simpleDateFormat에 저장된 정보를 저장
        dateTxtView.setText(today); // textView text 변환
    }

    public void onClick(View view){
        switch(view.getId()){
            case R.id.dateBtn:
                new DatePickerDialog(super.getContext(),dateSetListener, date.get(Calendar.YEAR),
                        date.get(Calendar.MONTH), date.get(Calendar.DAY_OF_MONTH)).show();
                updateLabel();
            default:
                break;
        }
    }
    private void updateLabel(){
        dateTxtView.setText(fmDateAndTime.format(date.getTime()));
    }

    public void setListener(){
        doneBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                HomeActivity homeActivity=(HomeActivity)getActivity();
                homeActivity.returnHome();
                homeActivity.setData(dateTxtView.getText().toString(),edt.getText().toString()); //날짜,내용을 homeActivity에서 만든 객체에 전달
            }
        });
    }
}