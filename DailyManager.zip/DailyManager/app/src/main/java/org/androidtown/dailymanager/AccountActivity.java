package org.androidtown.dailymanager;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AnalogClock;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class AccountActivity extends AppCompatActivity {

    private ImageButton diaryBtn,analyticsBtn,videoBtn;
    private DiaryAccountFragment diaryAccountFragment;
    private VideoAccountFragment videoAccountFragment;
    private AnalyticsAccountFragment analyticsAccountFragment;

    private ListView listView;
    private ArrayAdapter<String> adapter;
    private List<String> list=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account);

        init();
        setListener();
    }

    public void init(){
        diaryBtn=findViewById(R.id.account_diaryBtn);
        analyticsBtn=findViewById(R.id.account_analyticsBtn);
        videoBtn=findViewById(R.id.account_videoBtn);

        diaryBtn.setImageResource(R.drawable.on_diary_icon);

        diaryAccountFragment=new DiaryAccountFragment();
        videoAccountFragment=new VideoAccountFragment();
        analyticsAccountFragment=new AnalyticsAccountFragment();

        getSupportFragmentManager().beginTransaction().replace(R.id.account_fragment,diaryAccountFragment).commit();
    }

    public void setListener(){

        diaryBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                diaryBtn.setImageResource(R.drawable.on_diary_icon);
                videoBtn.setImageResource(R.drawable.video_icon);
                analyticsBtn.setImageResource(R.drawable.analytics_icon);

                getSupportFragmentManager().beginTransaction().replace(R.id.account_fragment,diaryAccountFragment).commit();
            }
        });

        videoBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                diaryBtn.setImageResource(R.drawable.diary_icon);
                videoBtn.setImageResource(R.drawable.on_video_icon);
                analyticsBtn.setImageResource(R.drawable.analytics_icon);

                getSupportFragmentManager().beginTransaction().replace(R.id.account_fragment,videoAccountFragment).commit();
            }
        });

        analyticsBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                diaryBtn.setImageResource(R.drawable.diary_icon);
                videoBtn.setImageResource(R.drawable.video_icon);
                analyticsBtn.setImageResource(R.drawable.on_analytics_icon);

                getSupportFragmentManager().beginTransaction().replace(R.id.account_fragment,analyticsAccountFragment).commit();
            }
        });
    }
}
