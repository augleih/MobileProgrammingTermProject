package org.androidtown.dailymanager;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.GridLayout;

/**
 * Created by Minsung on 2018-05-20.
 */

public class SubGridLayout extends GridLayout {

    public SubGridLayout(Context context){
        super(context);
    }
    public SubGridLayout(Context context,AttributeSet attrs){
        super(context,attrs);
    }
    private void init(Context context){
        LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.subgridlayout,this,true);
    }
}
